package VentanaColores;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaColores extends JFrame {

    private JPanel panel;

    public VentanaColores() {
        setTitle("Cambio de colores");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel principal
        panel = new JPanel();
        panel.setBackground(Color.WHITE);
        add(panel, BorderLayout.CENTER);

        // Panel para los botones
        JPanel panelBotones = new JPanel();

        JButton btnRojo = new JButton("Rojo");
        JButton btnVerde = new JButton("Verde");
        JButton btnAzul = new JButton("Azul");

        panelBotones.add(btnRojo);
        panelBotones.add(btnVerde);
        panelBotones.add(btnAzul);

        add(panelBotones, BorderLayout.SOUTH);

        // ActionListeners
        btnRojo.addActionListener(e -> panel.setBackground(Color.RED));
        btnVerde.addActionListener(e -> panel.setBackground(Color.GREEN));
        btnAzul.addActionListener(e -> panel.setBackground(Color.BLUE));
    }

    public static void main(String[] args) {
        new VentanaColores().setVisible(true);
    }
}
