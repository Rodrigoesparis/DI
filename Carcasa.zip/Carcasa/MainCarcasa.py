import sys
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QFileDialog, QMessageBox, QProgressBar, QLabel, QVBoxLayout, QWidget
)
from PySide6.QtCore import Qt
from carcasa import Ui_MainWindow


class VentanaPrincipal(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


        self.LblTitulo.setWordWrap(True)
        self.LblTitulo.setMinimumWidth(400)
        self.LblTitulo.setAlignment(Qt.AlignCenter)
        self.LblTitulo.move((self.width() - self.LblTitulo.width()) // 2, 80)


        self.widgetExtra = QWidget(self.centralwidget)
        self.widgetExtra.setGeometry(220, 250, 360, 80)
        self.layoutExtra = QVBoxLayout(self.widgetExtra)


        self.progressBar = QProgressBar()
        self.progressBar.setValue(30)  
        self.layoutExtra.addWidget(self.progressBar)


        self.lblTiempo = QLabel("00:00 / 03:45")
        self.lblTiempo.setAlignment(Qt.AlignCenter)
        self.layoutExtra.addWidget(self.lblTiempo)

        # --- Conexiones de menú ---
        self.menuAbrir.triggered.connect(self.abrir_archivo)
        self.menuSalir.aboutToShow.connect(self.confirmar_salida)

        # --- Conexiones de toolbar ---
        self.actionPlay.triggered.connect(lambda: self.LblTitulo.setText("▶️ Reproduciendo"))
        self.actionPause.triggered.connect(lambda: self.LblTitulo.setText("⏸️ Pausado"))
        self.actionStop.triggered.connect(lambda: self.LblTitulo.setText("⏹️ Detenido"))

    def abrir_archivo(self):
        ruta, _ = QFileDialog.getOpenFileName(self, "Abrir archivo", "", "Todos los archivos (*.*)")
        if ruta:
            QMessageBox.information(self, "Archivo abierto", f"Has abierto:\n{ruta}")

    def confirmar_salida(self):
        respuesta = QMessageBox.question(
            self,
            "Salir",
            "¿Seguro que quieres salir?",
            QMessageBox.Yes | QMessageBox.No
        )
        if respuesta == QMessageBox.Yes:
            self.close()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = VentanaPrincipal()
    ventana.show()
    sys.exit(app.exec())
